/*
	Database Ajax JS File
	Written by: Troy Grant
*/
(function($){

	
	
})(jQuery); // end private scope





